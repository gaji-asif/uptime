@extends('executive/layouts.app')

@section('content')
  <div class="content-wrapper">
    <div class="row profile-page">
      <div class="col-12">
        <div class="card">
          <div class="card-body">
            
            <div class="profile-body">
            <h4 class="card-title theme-color">Reward Details</h4>
             
                   <div class="row">
                     <div class="col-md-3">
                       <div class="form-group">

                        <h5 class="my-4">Reward Image</h5>

                        <div class="new-accounts reward-detail-image">
                          @if($reward->image != '')
                          <img src="<?php echo url('images/reward/'.$reward->image);?>" alt="Reward image" width="200px" height = "200px" onerror="this.src='<?php echo url('images/no_image.png'); ?>'">
                          @else
                          <div class="btn btn-outline-danger file-icon">
                            <i class="mdi mdi-image-broken"></i>
                          </div>
                          @endif
                        </div>
                        <br>
                            <p>created At :<strong> {{ $reward->created_at }}</strong></p>
                      </div>

                     </div>




                     <!-- list view  -->
                     <div class="col-md-9">
                           <div class="row">
                              <div class="col-lg-12 margin-tb">
                                <div class="pull-left">
                                    <h4 class="theme-color">Manage Employee</h4>
                                </div>
                   
                             </div>
                           </div>


                            <div class="row">
                                <div class="col-12">
                                    <div id="order-listing_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                        <div class="row">
                                            <div class="col-sm-12">
                                            
                                                <table id="order-listing" class="table dataTable no-footer" role="grid" aria-describedby="order-listing_info">
                                                    <thead>
                                                        <tr>
                                                            <th style="border-top:1px solid #f3f3f3;"><input type="checkbox" name="select_all" value="1" id="example-select-all"></th>
                                                            <!-- <td>id</td> -->
                                                            <td>Name</td>
                                                            <td>Image</td>
                                                            <td>Action</td>
                                                        </tr>
                                                    </thead>
                                
                                                </table>
                                            </div>
                                        </div>
                                  
                                        <div class="row">
                                            <div class="col-sm-12 col-md-5"></div>
                                            <div class="col-sm-12 col-md-7">
                                                <div class="dataTables_paginate paging_simple_numbers" id="order-listing_paginate">
                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>


                     </div>
                     <!-- end of list view  -->
              </div>
              <!-- end of row -->
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<style>
  .table td img, .jsgrid .jsgrid-table td img, .table th img, .jsgrid .jsgrid-table th img {
  //  width: 30%;
   // height: 15%;
    //border-radius: 50%;
  }
</style>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script>
  
$(function() {
  
   oderLinsting();
});

function oderLinsting(){

    if ( $.fn.DataTable.isDataTable('#order-listing') ) {
        $('#order-listing').DataTable().destroy();
    }
    $('#order-listing tbody').empty();        
    var ajax_url = '<?php echo url('executive/reward/useremployeedatatable');?>';
   
    var url2 = '<?php echo url('executive/reward/showemployee');?>';    
   
    var table = $('#order-listing').DataTable({
        processing: true,
        serverSide: true,

        ajax: ajax_url,
        "oLanguage": {
            "oPaginate": {
            "sFirst": "<i class='fa fa-chevron-left'></i><i class='fa fa-chevron-left'></i>",
            "sPrevious": "<i class='fa fa-chevron-left'></i>",
            "sNext": "<i class='fa fa-chevron-right'></i>",
            "sLast": "<i class='fa fa-chevron-right'></i><i class='fa fa-chevron-right'></i>" 
            }
        },
        columnDefs: [{
            'targets': 0,
            'searchable': false,
            'orderable': false,
            'className': 'dt-body-center',
            'render': function (data, type, full, meta){
                return '<input type="checkbox" name="id[]" value="' +full['id'] + '">';
            }
        }],
        columns: [
            {"bSortable": false},
            { data: 'full_name', name: 'full_name' },                      
            { data: 'image', name: 'image' },

            {"mRender": function ( data, type, row ) {
                  return "<a class='btn action-btn btn-outline-info' href="+url2+'/'+row['id']+"><i class='fa fa-eye'></i></a>"
              }
            },
        ],
        initComplete: function(settings, json) {
            if($('.dt-body-center').hasClass('sorting_asc')){
                $('.dt-body-center').removeClass('sorting_asc');
            }
        }
    });
    setTimeout(function(){
        multilpleCheckbox(table);
    }, 1000);
    
}

</script>
@endsection